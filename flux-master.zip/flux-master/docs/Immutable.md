---
id: immutable
title: ImmutableJS – Immutable Data
layout: docs
category: Complementary
permalink: http://facebook.github.io/immutable-js/
next: jest
---
